package uk.co.roke.baleen.consumers;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.apache.uima.analysis_engine.AnalysisEngine;
import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.fit.factory.AnalysisEngineFactory;
import org.apache.uima.fit.factory.ExternalResourceFactory;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.DocumentAnnotation;
import org.apache.uima.resource.ExternalResourceDescription;
import org.apache.uima.resource.ResourceAccessException;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.resource.impl.CustomResourceSpecifier_impl;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.google.common.collect.Iterables;
import com.tinkerpop.blueprints.Edge;

import co.uk.roke.baleen.consumers.Orient;
import co.uk.roke.baleen.consumers.SchemaKeys;
import co.uk.roke.baleen.resource.SharedOrientDBResource;
import edu.emory.mathcs.backport.java.util.Collections;
import uk.co.roke.baleen.types.copa.Agreement;
import uk.co.roke.baleen.types.copa.CoPaHead;
import uk.co.roke.baleen.types.copa.CoPaMention;
import uk.co.roke.baleen.types.copa.HeadModMatch;
import uk.co.roke.baleen.types.copa.MentionPair;
import uk.co.roke.baleen.types.copa.StrMatchNpron;
import uk.co.roke.baleen.types.copa.StrMatchPron;
import uk.gov.dstl.baleen.core.history.BaleenHistory;
import uk.gov.dstl.baleen.core.history.memory.InMemoryBaleenHistory;
import uk.gov.dstl.baleen.cpe.CpeBuilder;
import uk.gov.dstl.baleen.uima.utils.UimaTypesUtils;

/**
 * Unit tests for the orient consumer
 */
public class OrientTest extends ConsumerTestBase {
	private AnalysisEngine ae;
	SharedOrientDBResource sfr;
	private BaleenHistory history;

	/**
	 * Set up method, initialises the external resources and analysis engine
	 * 
	 * @throws ResourceInitializationException
	 * @throws ResourceAccessException
	 */
	@Before
	public void setUp() throws ResourceInitializationException, ResourceAccessException {
		// Creates an in-memory orient database to use in testing.
		ExternalResourceDescription erd = ExternalResourceFactory.createExternalResourceDescription("orient",
				SharedOrientDBResource.class, "orient.type", "memory", "orient.host", "local", "orient.db", "test1");

		ExternalResourceDescription historyErd = ExternalResourceFactory
				.createExternalResourceDescription(CpeBuilder.BALEEN_HISTORY, InMemoryBaleenHistory.class);

		history = Mockito.mock(BaleenHistory.class);

		// Create the analysis engine
		AnalysisEngineDescription aed = AnalysisEngineFactory.createEngineDescription(Orient.class, "orient", erd);

		ae = AnalysisEngineFactory.createEngine(aed);
		ae.initialize(new CustomResourceSpecifier_impl(), Collections.emptyMap());
		sfr = (SharedOrientDBResource) ae.getUimaContext().getResourceObject("orient");

		history = (BaleenHistory) ae.getUimaContext().getResourceObject(CpeBuilder.BALEEN_HISTORY);
		String dbUri = sfr.getOrientURI();

		// Ensure we're using a memory database for this test
		assertEquals("memory:local/test1", dbUri);
		assertEquals(0, Iterables.size(sfr.getOrientGraph().getVertices()));
	}

	/**
	 * Clean up after testing by clearing the database
	 */
	@After
	public void tearDown() {
		sfr.getOrientGraph().drop();
		if (ae != null) {
			ae.destroy();
		}
	}

	/**
	 * Tests a document can be inserted into the database, with no mentions or
	 * features
	 * 
	 * @throws Exception
	 */
	@Test
	public void testProcessSimpleDocument() throws Exception {
		createDocument(jCas, "This is some simple test data", "/test/data001", "test");

		// Process ae.process(jCas)
		ae.process(jCas);

		// We will have 1 Document class
		assertEquals(1, Iterables.size(sfr.getOrientGraph().getVerticesOfClass(SchemaKeys.DOCUMENT)));

		// We wont have any mention vertices yet
		assertEquals(0, Iterables.size(sfr.getOrientGraph().getVerticesOfClass(SchemaKeys.MENTION)));
	}

	/**
	 * Tests an "agreement" feature can be inserted into the database
	 * 
	 * @throws Exception
	 */
	@Test
	public void testProcessDocumentWithAgreement() throws Exception {
		// Set the document content
		createDocument(jCas, "This is some test data", "/test/data002", "test");

		Agreement ag = new Agreement(jCas);
		ag.setBegin(1);
		ag.setMatchingPair(createMentionPair(jCas, 1111111111L, 2222222222L, 17L));
		ag.addToIndexes();

		// Process ae.process(jCas)
		ae.process(jCas);

		// We will have 1 Document class
		assertEquals(1, Iterables.size(sfr.getOrientGraph().getVerticesOfClass(SchemaKeys.DOCUMENT)));

		// Two mention vertices should be in the graph
		assertEquals(2, Iterables.size(sfr.getOrientGraph().getVerticesOfClass(SchemaKeys.MENTION)));

		// There will be 3 edges in total in the graph.
		// - An edge between the document and each mention (i.e. 2 edges as
		// there are 2 mentions)
		// - 1 edge between the agreement mention pairs
		assertEquals(3, Iterables.size(sfr.getOrientGraph().getEdges()));

		// Only 1 feature edge for the agreement
		assertEquals(1, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "agreement")));

		// Verify the distance property has been set
		for (Edge e : sfr.getOrientGraph().getEdges()) {
			if (e.getProperty("feature_type") != null) {
				assertEquals(17, (long) e.getProperty("distance"));
				break;
			}
		}
	}

	/**
	 * Tests a "StrMatchNpron" feature can be inserted into the database
	 * 
	 * @throws Exception
	 */
	@Test
	public void testProcessDocumentWithStrMatchNpron() throws Exception {
		// Set the document content
		createDocument(jCas, "This is some test data", "/test/data002", "test");

		StrMatchNpron ag = new StrMatchNpron(jCas);
		ag.setBegin(1);
		ag.setMatchingPair(createMentionPair(jCas, 1111111111L, 2222222222L, 65));
		ag.addToIndexes();

		// Process ae.process(jCas)
		ae.process(jCas);

		// We will have 1 Document class
		assertEquals(1, Iterables.size(sfr.getOrientGraph().getVerticesOfClass(SchemaKeys.DOCUMENT)));

		// Two mention vertices should be in the graph
		assertEquals(2, Iterables.size(sfr.getOrientGraph().getVerticesOfClass(SchemaKeys.MENTION)));

		// There will be 3 edges in total in the graph.
		// - An edge between the document and each mention (i.e. 2 edges as
		// there are 2 mentions)
		// - 1 edge between the agreement mention pairs
		assertEquals(3, Iterables.size(sfr.getOrientGraph().getEdges()));

		// Check we don't have an agreement feature edge
		assertEquals(0, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "agreement")));

		// check we have a strMatchNpron feature edge
		assertEquals(1, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "strMatchNpron")));

		// Verify the distance property has been set
		for (Edge e : sfr.getOrientGraph().getEdges()) {
			if (e.getProperty("feature_type") != null) {
				assertEquals(65, (long) e.getProperty("distance"));
				break;
			}
		}
	}

	/**
	 * Tests a "StrMatchPron" feature can be inserted into the database
	 * 
	 * @throws Exception
	 */
	@Test
	public void testProcessDocumentWithStrMatchPron() throws Exception {
		// Set the document content
		createDocument(jCas, "This is some test data", "/test/data003", "test");

		StrMatchPron ag = new StrMatchPron(jCas);
		ag.setBegin(1);
		ag.setMatchingPair(createMentionPair(jCas, 1111111111L, 2222222222L, 56));
		ag.addToIndexes();

		// Process ae.process(jCas)
		ae.process(jCas);

		// We will have 1 Document class
		assertEquals(1, Iterables.size(sfr.getOrientGraph().getVerticesOfClass(SchemaKeys.DOCUMENT)));

		// Two mention vertices should be in the graph
		assertEquals(2, Iterables.size(sfr.getOrientGraph().getVerticesOfClass(SchemaKeys.MENTION)));

		// There will be 3 edges in total in the graph.
		// - An edge between the document and each mention (i.e. 2 edges as
		// there are 2 mentions)
		// - 1 edge between the agreement mention pairs
		assertEquals(3, Iterables.size(sfr.getOrientGraph().getEdges()));

		// Check we don't have an agreement feature edge
		assertEquals(0, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "agreement")));

		assertEquals(0, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "strMatchNpron")));

		// check we have a strMatchNpron feature edge
		assertEquals(1, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "strMatchPron")));

		// Verify the distance property has been set
		for (Edge e : sfr.getOrientGraph().getEdges()) {
			if (e.getProperty("feature_type") != null) {
				assertEquals(56, (long) e.getProperty("distance"));
				break;
			}
		}
	}

	/**
	 * Tests a "StrMatchNpron" feature can be inserted into the database
	 * 
	 * @throws Exception
	 */
	@Test
	public void testProcessDocumentWithSubString() throws Exception {
		// Set the document content
		createDocument(jCas, "This is some test data", "/test/data004", "test");

		HeadModMatch ag = new HeadModMatch(jCas);
		ag.setBegin(1);
		ag.setMatchingPair(createMentionPair(jCas, 1111111111L, 2222222222L, 5));
		ag.addToIndexes();

		// Process ae.process(jCas)
		ae.process(jCas);

		// We will have 1 Document class
		assertEquals(1, Iterables.size(sfr.getOrientGraph().getVerticesOfClass(SchemaKeys.DOCUMENT)));

		// Two mention vertices should be in the graph
		assertEquals(2, Iterables.size(sfr.getOrientGraph().getVerticesOfClass(SchemaKeys.MENTION)));

		// There will be 3 edges in total in the graph.
		// - An edge between the document and each mention (i.e. 2 edges as
		// there are 2 mentions)
		// - 1 edge between the agreement mention pairs
		assertEquals(3, Iterables.size(sfr.getOrientGraph().getEdges()));

		// Check we don't have an agreement feature edge
		assertEquals(0, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "agreement")));

		assertEquals(0, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "strMatchNpron")));

		// check we have a strMatchNpron feature edge
		assertEquals(0, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "strMatchPron")));

		assertEquals(1, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "headModMatch")));

		// Verify the distance property has been set
		for (Edge e : sfr.getOrientGraph().getEdges()) {
			if (e.getProperty("feature_type") != null) {
				assertEquals(5, (long) e.getProperty("distance"));
				break;
			}
		}
	}

	/**
	 * Tests that a document can be processed with multiple features
	 * 
	 * @throws Exception
	 */
	@Test
	public void testProcessDocumentMultipleFeatures() throws Exception {
		// Set the document content
		createDocument(jCas, "This is some test data", "/test/data004", "test");

		// there are 4 distinct mention vertices in this test
		long vertexID_1 = 1111L;
		long vertexID_2 = 2222L;
		long vertexID_3 = 3333L;
		long vertexID_4 = 4444L;

		Agreement ag = new Agreement(jCas);
		ag.setBegin(1);
		ag.setMatchingPair(createMentionPair(jCas, vertexID_1, vertexID_2, 18));
		ag.addToIndexes();

		HeadModMatch headModMatch = new HeadModMatch(jCas);
		headModMatch.setBegin(1);
		headModMatch.setMatchingPair(createMentionPair(jCas, vertexID_3, vertexID_2, 4));
		headModMatch.addToIndexes();

		StrMatchPron strMatchPron = new StrMatchPron(jCas);
		strMatchPron.setBegin(8);
		strMatchPron.setMatchingPair(createMentionPair(jCas, vertexID_3, vertexID_4, 13));
		strMatchPron.addToIndexes();

		// Process ae.process(jCas)
		ae.process(jCas);

		// We will have 1 Document class
		assertEquals(1, Iterables.size(sfr.getOrientGraph().getVerticesOfClass(SchemaKeys.DOCUMENT)));

		// Two mention vertices should be in the graph
		assertEquals(4, Iterables.size(sfr.getOrientGraph().getVerticesOfClass(SchemaKeys.MENTION)));

		// There will be 7 edges in total in the graph.
		// - An edge between the document and each mention (i.e. 4 edges as
		// there are 4 mentions)
		// - 1 edge between the agreement mention pairs vertexID_1 -> vertexID_2
		// - 1 edge between the agreement mention pairs vertexID_3 -> vertexID_2
		// - 1 edge between the agreement mention pairs vertexID_3 -> vertexID_4
		assertEquals(7, Iterables.size(sfr.getOrientGraph().getEdges()));

		// Check for the agreement feature edge
		assertEquals(1, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "agreement")));

		// We didn't set the "strMatchNpron", so should be 0
		assertEquals(0, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "strMatchNpron")));

		// check we have a strMatchNpron feature edge
		assertEquals(1, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "strMatchPron")));

		assertEquals(1, Iterables.size(sfr.getOrientGraph().getEdges("feature_type", "headModMatch")));

		// Verify the distance property has been set
		for (Edge e : sfr.getOrientGraph().getEdges()) {
			String fType = e.getProperty("feature_type");
			if (fType != null) {
				switch (fType) {
				case "agreement":
					assertEquals(18, (long) e.getProperty("distance"));
					break;
				case "strMatchPron":
					assertEquals(13, (long) e.getProperty("distance"));

					break;
				case "headModMatch":
					assertEquals(4, (long) e.getProperty("distance"));
					break;
				}
			}
		}
	}

	/**
	 * Helper method to generate a mention pair for use in the unit tests
	 * 
	 * @param jCas
	 *            Reference to the JCAS object
	 * @param idPrimary
	 *            The identifier of the primary mention in the pair
	 * @param idSecondary
	 *            The identifier of the secondary mention in the pair
	 * @return MentionPair
	 */
	private MentionPair createMentionPair(JCas jCas, long idPrimary, long idSecondary, long mentionDistance) {

		CoPaHead copaHead = new CoPaHead(jCas);
		copaHead.setBegin(1);
		copaHead.setEnd(2);
		copaHead.addToIndexes();

		final CoPaMention mentionPrimary = new CoPaMention(jCas);
		mentionPrimary.setInternalId(idPrimary);
		mentionPrimary.setMentionPosition(2);
		mentionPrimary.setMentionText("Test 001");
		mentionPrimary.setHead(copaHead);

		mentionPrimary.setGender("Male");
		mentionPrimary.setSemanticClass("TestClass");
		mentionPrimary.setSemanticType("TestType");

		mentionPrimary.setBegin(3);
		mentionPrimary.setEnd(4);

		mentionPrimary.addToIndexes();

		final CoPaMention mentionSecondary = new CoPaMention(jCas);
		mentionSecondary.setInternalId(idSecondary);
		mentionSecondary.setMentionPosition(2);
		mentionSecondary.setMentionText("Test 002");
		mentionSecondary.setHead(copaHead);

		mentionSecondary.setGender("Male");
		mentionSecondary.setSemanticClass("TestClass2");
		mentionSecondary.setSemanticType("TestType2");

		mentionSecondary.setBegin(8);
		mentionSecondary.setEnd(9);
		mentionSecondary.addToIndexes();

		final MentionPair mp = new MentionPair(jCas);
		mp.setPrimaryMention(mentionPrimary);
		mp.setSecondaryMention(mentionSecondary);
		mp.setMentionDistance(mentionDistance);
		mp.addToIndexes();

		return mp;
	}

	/**
	 * Creates a DocumentAnnotation
	 * 
	 * @param jCas
	 *            Reference to the JCAS object
	 * @param docText
	 *            Document text data
	 * @param source
	 *            The source string (i.e. the path of the document)
	 * @param type
	 *            The document type
	 * @return DocumentAnnotation
	 */
	private DocumentAnnotation createDocument(JCas jCas, String docText, String source, String type) {
		jCas.setDocumentText(docText);

		jCas.setDocumentLanguage("EN");

		long timestamp = System.currentTimeMillis();

		DocumentAnnotation da = getDocumentAnnotation(jCas);
		da.setTimestamp(timestamp);
		da.setSourceUri(source);
		da.setDocType(type);
		da.setDocumentClassification("OFFICIAL");
		da.setDocumentCaveats(UimaTypesUtils.toArray(jCas, Arrays.asList(new String[] { "TEST_A", "TEST_B" })));
		da.setDocumentReleasability(UimaTypesUtils.toArray(jCas, Arrays.asList(new String[] { "ENG", "SCO", "WAL" })));

		return da;
	}
}