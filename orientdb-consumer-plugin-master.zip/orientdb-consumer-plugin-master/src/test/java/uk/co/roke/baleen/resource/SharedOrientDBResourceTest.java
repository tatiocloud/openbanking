package uk.co.roke.baleen.resource;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Map;

import org.apache.uima.resource.Parameter;
import org.apache.uima.resource.impl.CustomResourceSpecifier_impl;
import org.apache.uima.resource.impl.Parameter_impl;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.Maps;

import co.uk.roke.baleen.resource.SharedOrientDBResource;

/**
 * Unit tests for the SharedOrientDBResource object
 */
public class SharedOrientDBResourceTest {

	SharedOrientDBResource sharedOrientDBResource;

	/**
	 * Set up method, initialises a CustomResourceSpecifier, creating a test database instance in memory
	 * @throws Exception
	 */
	@Before
	public void init() throws Exception {

		sharedOrientDBResource = new SharedOrientDBResource();

		CustomResourceSpecifier_impl esSpecifier = new CustomResourceSpecifier_impl();
		esSpecifier.setParameters(new Parameter[] { new Parameter_impl("orient.type", "memory"),
				new Parameter_impl("orient.host", "local"), new Parameter_impl("orient.db", "test1") });

		Map<String, Object> config = Maps.newHashMap();
		sharedOrientDBResource.initialize(esSpecifier, config);
	}

	/**
	 * Clean up method, destroys the shared resource object
	 * @throws IOException
	 */
	@After
	public void cleanUp() throws IOException {
		sharedOrientDBResource.destroy();
	}

	/**
	 * Verify the orient URI has changed from its default (plocal:localhost/baleen) to the in memory database
	 */
	@Test
	public void testOrientUrl() {
		// Tests the URL in the SharedOrientDBResource
		assertEquals("memory:local/test1", sharedOrientDBResource.getOrientURI());
	}
}