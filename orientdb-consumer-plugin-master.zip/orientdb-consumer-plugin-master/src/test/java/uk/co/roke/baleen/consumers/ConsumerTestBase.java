package uk.co.roke.baleen.consumers;

import org.apache.uima.fit.factory.JCasFactory;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.DocumentAnnotation;
import org.junit.Before;

/**
 * Base object for supporting orient consumer unit tests
 */
public class ConsumerTestBase {
	protected JCas jCas;

	/**
	 * Create a JCas object for testing
	 * 
	 * @throws Exception
	 */
	@Before
	public void beforeTest() throws Exception {
		jCas = JCasFactory.createJCas();

	}

	/**
	 * 
	 * @param jCas
	 *            The UIMA JCas object
	 * @return DocumentAnnotation
	 */
	protected DocumentAnnotation getDocumentAnnotation(JCas jCas) {
		return (DocumentAnnotation) jCas.getDocumentAnnotationFs();
	}
}