package co.uk.roke.baleen.consumers;

/**
 * Common strings, as used in the orient db schema in the definition of edge/vertex properties
 * and class definitions.
 */
public class SchemaKeys {
	public static final String FIELD_DOCUMENT_ID = "docId";
	public static final String FIELD_EXTERNAL_ID = "externalId";
	public static final String FIELD_INTERNAL_ID = "internalId";
	public static final String FIELD_ENTITIES = "entities";
	public static final String FIELD_DOCUMENT = "Document";
	public static final String FIELD_DOCUMENT_TYPE = "type";
	public static final String FIELD_DOCUMENT_SOURCE = "source";
	public static final String FIELD_HEAD_TEXT = "head_text";
	public static final String FIELD_DOCUMENT_LANGUAGE = "language";
	public static final String FIELD_DOCUMENT_TIMESTAMP = "timestamp";
	public static final String FIELD_DOCUMENT_CLASSIFICATION = "classification";
	public static final String FIELD_DOCUMENT_CAVEATS = "caveats";
	public static final String FIELD_DOCUMENT_RELEASABILITY = "releasability";
	public static final String FIELD_PUBLISHEDIDS = "publishedIds";
	public static final String FIELD_PUBLISHEDIDS_ID = "id";
	public static final String FIELD_PUBLISHEDIDS_TYPE = "type";
	public static final String FIELD_METADATA = "metadata";
	public static final String FIELD_CONTENT = "content";
	public static final String ENTITY = "entity";

	// Properties to add in the mentions/edges in the graph
	public static final String FIELD_GENDER = "gender";
	public static final String FIELD_SEM_CLASS = "semanticClass";
	public static final String FIELD_SEM_TYPE = "semanticType";
	public static final String FIELD_MENTION_TYPE = "mentionType";
	public static final String FIELD_MENTION_TEXT = "mentionText";
	public static final String FIELD_MENTION_POSN = "mentionPosition";
	public static final String FIELD_MENTION_BEGIN = "mentionBegin";
	public static final String FIELD_MENTION_END = "mentionEnd";
	public static final String FIELD_FEATURE_TYPE = "feature_type";
	public static final String FIELD_DISTANCE = "distance";

	// Class definitions for edge/vertex types
	public static final String CLASS = "class:";
	public static final String DOC_ENTITY = "DocEntity";
	public static final String FEATURE = "Feature";
	public static final String DOCUMENT = "Document";
	public static final String MENTION = "Mention";
	public static final String CLASS_DOC_ENTITY = "class:" + DOC_ENTITY;
	public static final String CLASS_FEATURE = "class:" + FEATURE;
	public static final String CLASS_DOCUMENT = "class:" + DOCUMENT;
	public static final String CLASS_MENTION = "class:" + MENTION;
}