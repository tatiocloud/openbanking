package co.uk.roke.baleen.consumers;

import static co.uk.roke.baleen.consumers.SchemaKeys.CLASS_DOCUMENT;
import static co.uk.roke.baleen.consumers.SchemaKeys.CLASS_DOC_ENTITY;
import static co.uk.roke.baleen.consumers.SchemaKeys.CLASS_FEATURE;
import static co.uk.roke.baleen.consumers.SchemaKeys.CLASS_MENTION;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_CONTENT;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_DISTANCE;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_DOCUMENT_CAVEATS;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_DOCUMENT_CLASSIFICATION;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_DOCUMENT_ID;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_DOCUMENT_LANGUAGE;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_DOCUMENT_RELEASABILITY;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_DOCUMENT_SOURCE;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_DOCUMENT_TIMESTAMP;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_DOCUMENT_TYPE;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_FEATURE_TYPE;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_GENDER;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_HEAD_TEXT;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_INTERNAL_ID;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_MENTION_BEGIN;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_MENTION_END;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_MENTION_POSN;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_MENTION_TEXT;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_MENTION_TYPE;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_METADATA;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_SEM_CLASS;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_SEM_TYPE;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.uima.UimaContext;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.descriptor.ConfigurationParameter;
import org.apache.uima.fit.descriptor.ExternalResource;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.cas.FSArray;
import org.apache.uima.jcas.tcas.DocumentAnnotation;
import org.apache.uima.resource.ResourceInitializationException;

import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;
import com.tinkerpop.blueprints.Edge;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.orient.OrientEdge;
import com.tinkerpop.blueprints.impls.orient.OrientGraphNoTx;

import co.uk.roke.baleen.resource.SharedOrientDBResource;
import uk.co.roke.baleen.types.copa.Agreement;
import uk.co.roke.baleen.types.copa.CoPaMention;
import uk.co.roke.baleen.types.copa.HeadModMatch;
import uk.co.roke.baleen.types.copa.MentionPair;
import uk.co.roke.baleen.types.copa.StrMatchNpron;
import uk.co.roke.baleen.types.copa.StrMatchPron;
import uk.co.roke.baleen.types.copa.SubString;
import uk.gov.dstl.baleen.consumers.utils.ConsumerUtils;
import uk.gov.dstl.baleen.types.metadata.Metadata;
import uk.gov.dstl.baleen.uima.BaleenConsumer;
import uk.gov.dstl.baleen.uima.utils.UimaTypesUtils;

/**
 * Output processed CAS object into Graph DB e.g. orient.
 * 
 * <p>
 * This consumer will output to OrientDB in a graph structure, which consists of
 * 3 elements as described below.
 * </p>
 * <p>
 * <b>documents</b>
 * </p>
 * These are represented as Vertex objects in the graph, with the class type of
 * "Document". These vertices are used to group together one or more mentions
 * within the same document.
 * 
 * <p>
 * <b>mentions</b>
 * </p>
 * <p>
 * Mentions are represented as Vertex objects, with the class type "Mention".
 * Mentions are automatically linked to the document vertex via an edge on
 * insertion, with the label "IsEntityOf".
 * </p>
 * 
 * <p>
 * <b>features</b>
 * </p>
 * <p>
 * Features are described through an edge that links two mentions. For example,
 * an "alias" feature (i.e. mention M1 is an alias of mention M2) would create
 * an edge between M1 and M2.
 *
 * @baleen.javadoc
 */
public class Orient extends BaleenConsumer {

	/**
	 * Connection to OrientDB
	 * 
	 * @baleen.resource SharedOrientDBResource
	 */
	public static final String KEY_ORIENT = "orient";
	@ExternalResource(key = KEY_ORIENT)
	private SharedOrientDBResource orientResource;

	/**
	 * Should a hash of the content be used to generate the ID? If false, then a
	 * hash of the Source URI is used instead.
	 * 
	 * @baleen.config true
	 */
	public static final String PARAM_CONTENT_HASH_AS_ID = "contentHashAsId";
	@ConfigurationParameter(name = PARAM_CONTENT_HASH_AS_ID, defaultValue = "true")
	private boolean contentHashAsId = true;

	/**
	 * Should we output the history to OrientDB?
	 * 
	 * @baleen.config false
	 */
	public static final String PARAM_OUTPUT_HISTORY = "outputHistory";
	@ConfigurationParameter(name = PARAM_OUTPUT_HISTORY, defaultValue = "false")
	private boolean outputHistory = false;

	/**
	 * Should we output the document content to OrientDB?
	 * 
	 * @baleen.config true
	 */
	public static final String PARAM_OUTPUT_CONTENT = "outputContent";
	@ConfigurationParameter(name = PARAM_OUTPUT_CONTENT, defaultValue = "false")
	private boolean outputContent = false;

	/**
	 * Enable "agreement" feature type processing
	 * 
	 * @baleen.config true
	 */
	public static final String PARAM_AGREEMENT = "agreement";
	@ConfigurationParameter(name = PARAM_AGREEMENT, defaultValue = "true")
	private boolean agreement = true;

	/**
	 * Enable "strMatchNpron" feature type processing
	 * 
	 * @baleen.config true
	 */
	public static final String PARAM_STR_MATCH_N_PRON = "strMatchNpron";
	@ConfigurationParameter(name = PARAM_STR_MATCH_N_PRON, defaultValue = "true")
	private boolean strMatchNpron = true;

	/**
	 * Enable "strMatchPron" feature type processing
	 * 
	 * @baleen.config true
	 */
	public static final String PARAM_STR_MATCH_PRON = "strMatchPron";
	@ConfigurationParameter(name = PARAM_STR_MATCH_PRON, defaultValue = "true")
	private boolean strMatchPron = true;

	/**
	 * Enable "substring" feature type processing
	 * 
	 * @baleen.config true
	 */
	public static final String PARAM_SUBSTRING = "substring";
	@ConfigurationParameter(name = PARAM_SUBSTRING, defaultValue = "true")
	private boolean substring = true;

	/**
	 * Enable "headModMatch" feature type processing
	 * 
	 * @baleen.config true
	 */
	public static final String PARAM_HEAD_MOD_MATCH = "headModMatch";
	@ConfigurationParameter(name = PARAM_HEAD_MOD_MATCH, defaultValue = "true")
	private boolean headModMatch = true;

	/**
	 * Holds the types of features that we're not interested in persisting
	 * (stuff from UIMA for example) We're storing these so that we can loop
	 * through the features (and then ignore some of them)
	 */
	private Set<String> stopFeatures;

	// OrientDB connection
	private OrientGraphNoTx db;

	/**
	 * Initialise the OrientDB connection
	 */
	@Override
	public void doInitialize(UimaContext aContext) throws ResourceInitializationException {
		// Connect to the Orient service to obtain a DB connection
		db = orientResource.getOrientGraph();

		stopFeatures = new HashSet<>();
		stopFeatures.add("uima.cas.AnnotationBase:sofa");
		stopFeatures.add("uk.gov.dstl.baleen.types.BaleenAnnotation:internalId");
	}

	@Override
	public void doDestroy() {
		// Intentionally blank, destroy handled by shared resource
	}

	/**
	 * Get the unique ID for the JCAS object
	 * 
	 * @param jCas
	 *            UIMA JCas object containing entities to process.
	 * @return String the unique document ID
	 */
	protected String getUniqueId(JCas jCas) {
		return ConsumerUtils.getExternalId(getDocumentAnnotation(jCas), contentHashAsId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * uk.gov.dstl.baleen.uima.BaleenAnnotator#doProcess(org.apache.uima.jcas.
	 * JCas)
	 */
	@Override
	protected void doProcess(JCas jCas) throws AnalysisEngineProcessException {
		final String documentId = getUniqueId(jCas);

		// Save graph
		buildGraph(documentId, jCas);
	}

	/**
	 * Creates the graph structure in OrientDB, setting the properties from the
	 * jCas object
	 * 
	 * @param documentId
	 *            Unique document ID
	 * @param jCas
	 *            UIMA JCas object containing entities to process.
	 */
	private void buildGraph(String documentId, JCas jCas) {
		final DocumentAnnotation da = getDocumentAnnotation(jCas);

		// Create the document vertices
		try {
			final Vertex vDocument = db.addVertex(CLASS_DOCUMENT);

			if (da.getDocType() != null) {
				vDocument.setProperty(FIELD_DOCUMENT_TYPE, da.getDocType());
			}

			if (da.getSourceUri() != null) {
				vDocument.setProperty(FIELD_DOCUMENT_SOURCE, da.getSourceUri());
			}

			if (da.getLanguage() != null) {
				vDocument.setProperty(FIELD_DOCUMENT_LANGUAGE, da.getLanguage());
			}

			vDocument.setProperty(FIELD_DOCUMENT_TIMESTAMP, new Date(da.getTimestamp()));

			if (da.getDocumentClassification() != null) {
				vDocument.setProperty(FIELD_DOCUMENT_CLASSIFICATION, da.getDocumentClassification());
			}

			if (da.getDocumentCaveats() != null) {
				vDocument.setProperty(FIELD_DOCUMENT_CAVEATS, UimaTypesUtils.toArray(da.getDocumentCaveats()));
			}

			if (da.getDocumentReleasability() != null) {
				vDocument.setProperty(FIELD_DOCUMENT_RELEASABILITY,
						UimaTypesUtils.toArray(da.getDocumentReleasability()));
			}

			// Meta data
			final Multimap<String, Object> meta = MultimapBuilder.linkedHashKeys().linkedListValues().build();
			for (Metadata metadata : JCasUtil.select(jCas, Metadata.class)) {
				final String key = metadata.getKey();
				meta.put(key, metadata.getValue());
			}

			if (meta.asMap() != null) {
				vDocument.setProperty(FIELD_METADATA, meta.asMap());
			}

			// Add full document content, if requested
			if (outputContent) {
				vDocument.setProperty(FIELD_CONTENT, jCas.getDocumentText());
			}

			vDocument.setProperty(FIELD_DOCUMENT_ID, documentId);

			// Build graph based on COPA mention/feature extraction
			processCopaMention(documentId, jCas, vDocument);
		} catch (Exception e) {
			getMonitor().error("Error processing graph " + e.getMessage());
		}
	}

	/**
	 * Entry point to COPA mention processing, invokes the various feature
	 * extractors based on the specified configuration.
	 * 
	 * @param documentId
	 *            Reference to the document ID
	 * @param jCas
	 *            UIMA JCas object containing entities to process.
	 * @param vDocument
	 *            The document vertex
	 */
	private void processCopaMention(String documentId, JCas jCas, final Vertex vDocument) {
		getMonitor().info("processCopaMention");
		
		// Create the mentions
		for(CoPaMention copaMention : JCasUtil.select(jCas, CoPaMention.class)){
			this.getOrCreateMentionVertex(copaMention, vDocument, jCas);
		}

		// Invove processing based on the configuration
		if (agreement)
			processAgreement(jCas, vDocument);

		if (strMatchNpron)
			processStrMatchNpron(jCas, vDocument);

		if (strMatchPron)
			processStrMatchPron(jCas, vDocument);

		if (substring)
			processSubstring(jCas, vDocument);

		if (headModMatch)
			processHeadModMatch(jCas, vDocument);

		getMonitor().info("DONE - processCopaMention");
	}

	/**
	 * Get existing mention, or create a new one if it doesn't exist already.  The following
	 * properties are set on the mention vertex object:
	 * <p>
	 * 
	 * <ul>
	 * <li>class:Mention	-	Orient class type, used to identify this as a Mention object type<li>
	 * <li>docId			- 	The unique document ID (generated by Baleen annotation)<li>
	 * <li>source			-	The document source (i.e. the full path to the document)<li>
	 * <li>gender			-	The gender of the mention, as extracted by JET (if applicable)<li>
	 * <li>semanticClass	-	The semantic class, as extracted by JET (e.g. Person, Object)<li>
	 * <li>semanticType		-	The semantic type, as extracted by JET (e.g. Location, Organisation)<li>
	 * <li>mentionType		-	The mention type, as extracted by JET<li>
	 * <li>internalId		-	The internal ID (generated by Baleen annotation)<li>
	 * <li>mentionText		-	The mention text, as extracted by JET<li>
	 * <li>mentionPosition	-	The position in the document of the mention<li>
	 * <li>mentionBegin		-	The start position on the document of the mention<li>
	 * <li>mentionEnd		-	The end position on the document of the mention<li>
	 * <li>headText			-	The head text, which is a substring of the mention text<li>
	 * </ul>
	 * 
	 * @param copaMention
	 *            The custom COPAMention type
	 * @param vDocument
	 *            The document vertex object (i.e. class:Document)
	 * @param jCas
	 *            UIMA JCas object containing entities to process.
	 * @return The created mention vertex object
	 */
	private Vertex getOrCreateMentionVertex(CoPaMention copaMention, final Vertex vDocument, JCas jCas) {
		// First, check to see if we already have a vertex in the graph for this
		// mention
		final Iterable<Vertex> existingMentions = db.getVertices(FIELD_INTERNAL_ID, copaMention.getInternalId());

		for (Vertex mention : existingMentions) {
			getMonitor().debug("Found Existing Mention {}", mention);
			return mention;
		}

		// If mention vertex doesn't exist, create a new one
		final Vertex vMention = db.addVertex(CLASS_MENTION);
		if (vDocument.getProperty(FIELD_DOCUMENT_ID) != null) {
			vMention.setProperty(FIELD_DOCUMENT_ID, vDocument.getProperty(FIELD_DOCUMENT_ID));
		} else {
			getMonitor().error("Document ID is null");
		}

		// Set the properties on the mention vertex object
		vMention.setProperty(FIELD_GENDER, copaMention.getGender() != null ? copaMention.getGender() : "");
		vMention.setProperty(FIELD_SEM_CLASS,
				copaMention.getSemanticClass() != null ? copaMention.getSemanticClass() : "");
		vMention.setProperty(FIELD_SEM_TYPE,
				copaMention.getSemanticType() != null ? copaMention.getSemanticType() : "");
		vMention.setProperty(FIELD_MENTION_TYPE,
				copaMention.getType().getName() != null ? copaMention.getType().getName() : "");
		vMention.setProperty(FIELD_INTERNAL_ID, copaMention.getInternalId());
		vMention.setProperty(FIELD_MENTION_TEXT,
				copaMention.getMentionText() != null ? copaMention.getMentionText() : "");
		vMention.setProperty(FIELD_MENTION_POSN, copaMention.getMentionPosition());
		vMention.setProperty(FIELD_MENTION_BEGIN, copaMention.getBegin());
		vMention.setProperty(FIELD_MENTION_END, copaMention.getEnd());
		vMention.setProperty(FIELD_DOCUMENT_ID, vDocument.getProperty(FIELD_DOCUMENT_ID));
		vMention.setProperty(FIELD_DOCUMENT_SOURCE, vDocument.getProperty(FIELD_DOCUMENT_SOURCE));

		// Set the head text by extracting from the copa mention head
		if (jCas.getDocumentText() != null && copaMention.getHead() != null) {
			vMention.setProperty(FIELD_HEAD_TEXT,
					jCas.getDocumentText().substring(copaMention.getHead().getBegin(), copaMention.getHead().getEnd()));
		} else {
			vMention.setProperty(FIELD_HEAD_TEXT, " ");
		}

		// Add an edge between this entity and the document object
		db.addEdge(CLASS_DOC_ENTITY, vMention, vDocument, "isAnEntityOf");

		return vMention;
	}

	/**
	 * Creates an edge in orient db between a pair of vertices
	 * 
	 * @param v1
	 *            the first vertex in the pair
	 * @param v2
	 *            the second vertex in the pair
	 * @param featureType
	 *            String description of the feature type
	 * @param mentionDistance
	 *            The mention distance (i.e. distance between intervening
	 *            mentions)
	 * @return Edge the edge object to persist in orient
	 */
	private Edge createFeatureEdge(Vertex v1, Vertex v2, String featureType, long mentionDistance) {
		final OrientEdge edge = db.addEdge(CLASS_FEATURE, v1, v2, featureType);
		edge.setProperty(FIELD_FEATURE_TYPE, featureType);
		edge.setProperty(FIELD_DISTANCE, mentionDistance);
		return edge;
	}

	private void processMentions(JCas jCas) {

	}
	/**
	 * Process Agreement feature types.
	 * <p>
	 * 
	 * @param jCas
	 *            UIMA JCas object containing entities to process.
	 * @param vDocument
	 *            Vertex object to retain reference to source document
	 */
	private void processAgreement(JCas jCas, final Vertex vDocument) {
		getMonitor().info("processAgreement");
		for (Agreement agree : JCasUtil.select(jCas, Agreement.class)) {
			Vertex v1 = null;
			Vertex v2 = null;
			MentionPair mp = agree.getMatchingPair();
			if (mp != null) {
				CoPaMention primary = mp.getPrimaryMention();
				CoPaMention secondary = mp.getSecondaryMention();
				if (primary != null) {
					v1 = getOrCreateMentionVertex(primary, vDocument, jCas);
				}
				if (secondary != null) {
					v2 = getOrCreateMentionVertex(secondary, vDocument, jCas);
				}
			}
			if (v1 != null && v2 != null) {
				createFeatureEdge(v1, v2, "agreement", mp.getMentionDistance());
			}
		}
		getMonitor().info("DONE - processAgreement");
	}

	/**
	 * Process StrMatchNpron feature type.
	 * <p>
	 * 
	 * @param aJCas
	 *            UIMA JCas object containing entities to process.
	 * @param vDocument
	 *            Vertex object to retain reference to source document
	 */
	private void processStrMatchNpron(JCas jCas, final Vertex vDocument) {
		getMonitor().info("processStrMatchNpron");
		for (StrMatchNpron strNpron : JCasUtil.select(jCas, StrMatchNpron.class)) {
			Vertex v1 = null;
			Vertex v2 = null;
			MentionPair mp = strNpron.getMatchingPair();
			if (mp != null) {
				CoPaMention primary = mp.getPrimaryMention();
				CoPaMention secondary = mp.getSecondaryMention();
				if (primary != null) {
					v1 = getOrCreateMentionVertex(primary, vDocument, jCas);
				}
				if (secondary != null) {
					v2 = getOrCreateMentionVertex(secondary, vDocument, jCas);
				}
			}
			if (v1 != null && v2 != null) {
				createFeatureEdge(v1, v2, "strMatchNpron", mp.getMentionDistance());
			}

		}
		getMonitor().info("DONE - processStrMatchNpron");
	}

	/**
	 * Process StrMatchPron feature type
	 * <p>
	 * 
	 * @param jCas
	 *            UIMA JCas object containing entities to process.
	 * @param vDocument
	 *            Vertex object to retain reference to source document
	 */
	private void processStrMatchPron(JCas jCas, final Vertex vDocument) {
		getMonitor().info("processStrMatchPron");
		for (StrMatchPron strPron : JCasUtil.select(jCas, StrMatchPron.class)) {
			Vertex v1 = null;
			Vertex v2 = null;
			MentionPair mp = strPron.getMatchingPair();
			if (mp != null) {
				CoPaMention primary = mp.getPrimaryMention();
				CoPaMention secondary = mp.getSecondaryMention();
				if (primary != null) {
					v1 = getOrCreateMentionVertex(primary, vDocument, jCas);
				}
				if (secondary != null) {
					v2 = getOrCreateMentionVertex(secondary, vDocument, jCas);
				}
			}
			if (v1 != null && v2 != null) {
				createFeatureEdge(v1, v2, "strMatchPron", mp.getMentionDistance());
			}
		}

		getMonitor().info("DONE - processStrMatchPron");
	}

	/**
	 * Process SubString feature type.
	 * <p>
	 * 
	 * @param jCas
	 *            UIMA JCas object containing items to process.
	 * @param vDocument
	 *            Vertex object to retain reference to source document
	 */
	private void processSubstring(JCas jCas, final Vertex vDocument) {
		getMonitor().info("processSubstring");
		for (SubString subStr : JCasUtil.select(jCas, SubString.class)) {
			Vertex v1 = null;
			Vertex v2 = null;
			FSArray matches = subStr.getSubStringList();
			for (int midx = 0; (matches != null) && (midx < matches.size()); midx++) {
				MentionPair mp = (MentionPair) matches.get(midx);
				if (mp != null) {
					CoPaMention primary = mp.getPrimaryMention();
					CoPaMention secondary = mp.getSecondaryMention();
					if (primary != null) {
						v1 = getOrCreateMentionVertex(primary, vDocument, jCas);
					}
					if (secondary != null) {
						v2 = getOrCreateMentionVertex(secondary, vDocument, jCas);
					}
				}
				if (v1 != null && v2 != null) {
					createFeatureEdge(v1, v2, "substring", mp.getMentionDistance());
				}
			}
		}

		getMonitor().info("DONE - processSubstring");
	}

	/**
	 * Process HeadModMatch feature type.
	 * <p>
	 * 
	 * @param jCas
	 *            UIMA JCas object containing items to process.
	 * @param vDocument
	 *            Vertex object to retain reference to source document
	 */
	private void processHeadModMatch(JCas jCas, Vertex vDocument) {
		getMonitor().info("processHeadModMatch");
		for (HeadModMatch hmm : JCasUtil.select(jCas, HeadModMatch.class)) {
			Vertex v1 = null;
			Vertex v2 = null;
			MentionPair mp = hmm.getMatchingPair();
			if (mp != null) {
				CoPaMention primary = mp.getPrimaryMention();
				CoPaMention secondary = mp.getSecondaryMention();
				if (primary != null) {
					v1 = getOrCreateMentionVertex(primary, vDocument, jCas);
				}
				if (secondary != null) {
					v2 = getOrCreateMentionVertex(secondary, vDocument, jCas);
				}
			}
			if (v1 != null && v2 != null) {
				createFeatureEdge(v1, v2, "headModMatch", mp.getMentionDistance());
			}
		}
		getMonitor().info("DONE - processHeadModMatch");
	}
}