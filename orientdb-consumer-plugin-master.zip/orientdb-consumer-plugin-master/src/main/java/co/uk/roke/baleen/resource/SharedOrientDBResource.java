package co.uk.roke.baleen.resource;

import static co.uk.roke.baleen.consumers.SchemaKeys.DOCUMENT;
import static co.uk.roke.baleen.consumers.SchemaKeys.DOC_ENTITY;
import static co.uk.roke.baleen.consumers.SchemaKeys.FEATURE;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_DOCUMENT_ID;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_DOCUMENT_TIMESTAMP;
import static co.uk.roke.baleen.consumers.SchemaKeys.FIELD_INTERNAL_ID;
import static co.uk.roke.baleen.consumers.SchemaKeys.MENTION;

import java.util.Map;

import org.apache.uima.fit.descriptor.ConfigurationParameter;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.resource.ResourceSpecifier;

import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.orient.OrientGraphFactory;
import com.tinkerpop.blueprints.impls.orient.OrientGraphNoTx;

import uk.gov.dstl.baleen.exceptions.BaleenException;
import uk.gov.dstl.baleen.uima.BaleenResource;

/**
 * <b>Shared resource for accessing OrientDB</b>
 * <p>
 * This resource removes the need for individual annotators to establish their
 * own connections to Orient, instead providing a single OrientGraph instance
 * for Baleen that can be used. This provides benefits such as reduced
 * configuration, reduced repeated code, and support for connection pooling.
 * </p>
 *
 * 
 * @baleen.javadoc
 */
public class SharedOrientDBResource extends BaleenResource {
	private OrientGraphFactory orientGraphFactory;

	// Connection pool parameters
	private static final Integer MIN_POOL_SIZE = 1;
	private static final Integer MAX_POOL_SIZE = 10;

	private OrientGraphNoTx orientGraph;

	/**
	 * The OrientDB host to connect to
	 * 
	 * @baleen.config localhost
	 */
	public static final String PARAM_HOST = "orient.host";
	@ConfigurationParameter(name = PARAM_HOST, defaultValue = "127.0.0.1")
	private String orientHost;

	/**
	 * The Orient database to connect to
	 * 
	 * @baleen.config baleen
	 */
	public static final String PARAM_DB = "orient.db";
	@ConfigurationParameter(name = PARAM_DB, defaultValue = "baleen")
	private String orientDb;

	/**
	 * The Orient database type (e.g. plocal, remote, memory)
	 * 
	 * @baleen.config baleen
	 */
	public static final String PARAM_DB_TYPE = "orient.type";
	@ConfigurationParameter(name = PARAM_DB_TYPE, defaultValue = "plocal")
	private String orientDbType;

	@Override
	protected boolean doInitialize(ResourceSpecifier aSpecifier, Map<String, Object> aAdditionalParams)
			throws ResourceInitializationException {
		try {
			connectToOrient();
		} catch (BaleenException be) {
			throw new ResourceInitializationException(be);
		}

		getMonitor().info("Initialised shared OrientDB resource");

		return true;
	}

	/**
	 * Connect to, and initialise the orient database. This involved creating
	 * the internal edge and vertex types required to store the structures, and
	 * creates indexes on fields to improve query performance.
	 * 
	 * @throws BaleenException
	 */
	private void connectToOrient() throws BaleenException {
		try {
			if (this.orientGraph == null) {
				this.orientGraph = createOrientGraph();
			}

			// Create the edge and vertex types in orient
			if (this.getOrientGraph().getEdgeType(DOC_ENTITY) == null)
				this.getOrientGraph().createEdgeType(DOC_ENTITY);

			if (this.getOrientGraph().getEdgeType(FEATURE) == null)
				this.getOrientGraph().createEdgeType(FEATURE);

			if (this.getOrientGraph().getVertexType(DOCUMENT) == null)
				this.getOrientGraph().createVertexType(DOCUMENT);

			if (this.getOrientGraph().getVertexType(MENTION) == null)
				this.getOrientGraph().createVertexType(MENTION);

			if (this.getOrientGraph().getIndexedKeys(Vertex.class).size() == 0) {
				this.getOrientGraph().createKeyIndex(FIELD_DOCUMENT_ID, Vertex.class);
				this.getOrientGraph().createKeyIndex(FIELD_DOCUMENT_TIMESTAMP, Vertex.class);
				this.getOrientGraph().createKeyIndex(FIELD_INTERNAL_ID, Vertex.class);
			}

			getMonitor().debug("Getting Orient Database '{}'", orientGraph);
		} catch (Exception e) {
			throw new BaleenException("Unable to connect to OrientDB", e);
		}
	}

	@Override
	protected void doDestroy() {
		getMonitor().debug("Disconnecting from OrientDB");

		// Close the graph database completely.
		this.orientGraph.shutdown();

		this.orientGraph = null;
	}

	/**
	 * Creates an OrientDB graph
	 * 
	 * @return OrientGraphNoTx 
	 *            The created graph instance
	 */
	public OrientGraphNoTx createOrientGraph() {
		if (orientGraphFactory == null) {
			orientGraphFactory = new OrientGraphFactory(this.getOrientURI());
			orientGraphFactory.setupPool(MIN_POOL_SIZE, MAX_POOL_SIZE);
		}

		return orientGraphFactory.getNoTx();
	}

	/**
	 * Get the orient graph instance
	 * 
	 * @return OrientGraphNoTx The orient graph object reference
	 */
	public OrientGraphNoTx getOrientGraph() {
		return orientGraph;
	}

	/**
	 * Set the orient graph reference
	 * 
	 * @param orientGraph
	 *            OrientGraphNoTx
	 */
	public void setOrientGraph(OrientGraphNoTx orientGraph) {
		this.orientGraph = orientGraph;
	}

	/**
	 * Creates an OrientDB URI string, without the username:password
	 * 
	 * @return String The orient graph formatted URI string
	 */
	public String getOrientURI() {
		return orientDbType + ":" + orientHost + "/" + orientDb;
	}
}