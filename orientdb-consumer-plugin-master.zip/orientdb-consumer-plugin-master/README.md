# Orient Consumer Plugin

The orient-consumer-plugin (graph-consumer-0.0.1-SNAPSHOT.jar) provides a Baleen consumer that allows the documents,
entities and relations to be output into an OrientDB graph database.  This can be used for a variety of purposes,
and is a key enabler in cross-document coreferencing and resolution.

This plugin is written in [Java 8](http://www.oracle.com/java/javase/downloads/jre8-downloads-2133155.html) using the software project management tool [Maven 3](http://maven.apache.org).

# Dependancies
To build the orient-consumer-plugin software using Maven, there are two dependancies that need to be loaded into the Maven repository.  These are the JET libraries and the jcastypes jar.  This can be done as follows:

`mvn install:install-file -Dfile=${path_to_jet}/jet-all.jar -DgroupId=org.jet -DartifactId=jet -Dversion=150509 -Dpackaging=jar`
`mvn install:install-file -Dfile=${path_to_jcastypes}/jcastypes-0.0.1-SNAPSHOT.jar -DgroupId=uk.co.roke.baleen.types.copa -DartifactId=jcastypes -Dversion=0.0.1 -Dpackaging=jar`

After these are installed, run the command `mvn clean package` to compile the orient-consumer-plugin software.

# Getting Started
The orient-consumer-plugin software has been built against a specific version of Orient (2.1.9), support for future
versions is dependent on any subsequent API changes.

The plugin is a Baleen consumer and is loaded and invoked through the standard Baleen configuration mechanism. It is recommended that the README.md file in the Baleen GitHub project is consulted for information on how to configure Baleen.

The Java class path and key resources must be configured to ensure the jar files for the plugin and the Jet software are located.  A simple pipeline has been produced (runner.yaml and pipeline.yaml) which processes the data.txt file and outputs
the jCas object to the orient consumer plugin for persistance in the graph database.

### YAML Config
To use the consumer, it must be included within the Baleen pipeline.  the following is a basic configuration:

    - class: co.uk.roke.baleen.consumers.Orient
      agreement: true
      strMatchPron: true
      strMatchNpron: true
      substring: true
      headModMatch: true

The orient database defaults to localhost, so the database will be stored in a folder called "127.0.0.1/baleen".

Note that the COPA feature extractors can be individually controlled.  they all default to true, however, if a 
feature needs to be disabled then it can be set to false.

### Example Usage
`java -cp ${path_to_baleen}/baleen-2.1.0.jar:${path_to_orient_consumer}/graph-consumer-0.0.1-SNAPSHOT.jar uk.gov.dstl.baleen.runner.Baleen  ${path_to_baleen}/runner.yaml`

